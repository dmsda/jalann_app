import 'package:flutter/material.dart';
import 'package:jalan_app/widget/carousel_slide.dart';
import 'package:jalan_app/widget/related_tour.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:jalan_app/theme/theme_cubit.dart';

class Beranda extends StatefulWidget {
  const Beranda({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _BerandaState createState() => _BerandaState();
}

class _BerandaState extends State<Beranda> {
  int _currentTab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(vertical: 30.0),
          children: <Widget>[
            Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Dark Mode',
                  style: Theme.of(context).textTheme.button,
                ),
                const SizedBox(
                  width: 30,
                ),
                BlocBuilder<ThemeCubit, ThemeMode>(
                  builder: (context, themeMode) => CupertinoSwitch(
                    value: themeMode == ThemeMode.dark,
                    onChanged: (value) {
                      //// Mengubah mode terang ke gelap atau sebaliknya
                      BlocProvider.of<ThemeCubit>(context).changeThame();
                    },
                  ),
                ),
              ],
            ),
            const Padding(
              padding: EdgeInsets.only(left: 15.0, right: 50.0),
              child: Text(
                'Jalann App',
                style: TextStyle(
                    fontSize: 30.0,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Poppins'),
              ),
            ),
            const SizedBox(height: 20.0),
            const SizedBox(
              height: 10.0,
            ),
            const CarouselSlide(),
            const SizedBox(
              height: 10.0,
            ),
            const CarouselSlide2(),
            const SizedBox(
              height: 10.0,
            )
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentTab,
        onTap: (int value) {
          setState(() {
            _currentTab = value;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(
              Icons.search,
              size: 20.0,
            ),
            label: 'Search',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.home,
              size: 20.0,
            ),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.settings,
              size: 20.0,
            ),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}
