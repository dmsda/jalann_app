import 'package:jalan_app/model/aktivitas_model.dart';

class Destination {
  String imageUrl;
  String city;
  String country;
  String description;
  List<Activity> activities;

  Destination({
    required this.imageUrl,
    required this.city,
    required this.country,
    required this.description,
    required this.activities,
  });
}

List<Activity> activities = [
  Activity(
    imageUrl: 'assets/images/korea2.jpg',
    name: 'Korea Castle',
    type: 'Culture',
    startTimes: ['08 am', 'no time'],
    rating: 4,
    price: 500,
  ),
  Activity(
    imageUrl: 'assets/images/everest2.jpg',
    name: 'Everest Hiking',
    type: 'Hiking',
    startTimes: ['6 am', 'no time'],
    rating: 5,
    price: 900,
  ),
  Activity(
    imageUrl: 'assets/images/kalimantan2.jpg',
    name: 'Kalimantan Explorer',
    type: 'Tour',
    startTimes: ['6 am', 'no time'],
    rating: 5,
    price: 700,
  ),
  Activity(
    imageUrl: 'assets/images/piramids2.jpg',
    name: 'Piramids Museum',
    type: 'Museum',
    startTimes: ['6 am', 'no time'],
    rating: 4,
    price: 900,
  ),
];

List<Destination> destinations = [
  Destination(
    imageUrl: 'assets/images/everest.jpg',
    city: 'Mount Everest',
    country: 'Himalaya, Nepal',
    description: 'Wisata mancanegara banyak ceritanya',
    activities: activities,
  ),
  Destination(
    imageUrl: 'assets/images/kalimantan.jpg',
    city: 'Kalimantan',
    country: 'Indonesia',
    description: 'Wisata mancanegara banyak ceritanya',
    activities: activities,
  ),
  Destination(
    imageUrl: 'assets/images/piramids.jpg',
    city: 'Egypt',
    country: 'Mesir',
    description: 'Wisata mancanegara banyak ceritanya',
    activities: activities,
  ),
  Destination(
    imageUrl: 'assets/images/korea.jpg',
    city: 'Seoul',
    country: 'Korea',
    description: 'Wisata mancanegara banyak ceritanya',
    activities: activities,
  ),
  Destination(
    imageUrl: 'assets/images/kalimantan1.jpg',
    city: 'Kalimantan',
    country: 'Indonesia',
    description: 'Wisata mancanegara banyak ceritanya',
    activities: activities,
  ),
];
