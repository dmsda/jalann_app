class Nature {
  String imageUrl;
  String name;
  String address;
  int price;

  Nature({
    required this.imageUrl,
    required this.name,
    required this.address,
    required this.price,
  });
}

final List<Nature> natures = [
  Nature(
    imageUrl: 'assets/images/everest2.jpg',
    name: 'Everest',
    address: 'Himalaya, Nepal',
    price: 1000,
  ),
  Nature(
    imageUrl: 'assets/images/kalimantan2.jpg',
    name: 'Kalimantan',
    address: 'Indonesia, Kalimantan',
    price: 300,
  ),
  Nature(
    imageUrl: 'assets/images/piramids2.jpg',
    name: 'Piramids',
    address: 'Egypt, Mesir',
    price: 950,
  ),
];
